
export interface Variant {
  id: string
  title: string
  price?: string
  currency?: string
  show_price?: boolean
  description?: string
  color?: string
}